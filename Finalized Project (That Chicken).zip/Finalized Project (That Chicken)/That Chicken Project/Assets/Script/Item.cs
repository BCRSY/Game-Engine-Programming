﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour {

    public bool DestroyCoin = true;
	public int scoreValue;
	public Scoring scoring;

    // Use this for initialization
    void Start () {
		GameObject scoringObject = GameObject.FindWithTag ("Score");
		if (scoringObject != null) {
			scoring = scoringObject.GetComponent <Scoring>();
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnTriggerStay()
    {
        if (DestroyCoin == true)
        {
            gameObject.SetActive(false);
			scoring.AddScore (scoreValue);
        }
    }
}
