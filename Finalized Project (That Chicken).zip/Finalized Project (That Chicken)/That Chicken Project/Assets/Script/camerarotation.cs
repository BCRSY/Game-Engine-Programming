﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camerarotation : MonoBehaviour {
	private float smooth = 3f;
	private float DistanceAway = 3f;
	private float DistanceUp = 2f;
	private Transform follow;
	private Vector3 TargetPosition;


	// Use this for initialization
	void Start () {
		follow = GameObject.FindWithTag ("Player").transform;
	}
	
	// Update is called once per frame
	void LateUpdate () {
		TargetPosition = follow.position + follow.up * DistanceUp - follow.forward * DistanceAway;

		transform.position = Vector3.Lerp (transform.position, TargetPosition, Time.deltaTime * smooth);

		transform.LookAt (follow);
	}
}
