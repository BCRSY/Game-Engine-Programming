﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class movement : MonoBehaviour {


	float speed = 5f;
	int rotate = 150;


	// Use this for initialization
	void Start () {
		
	}

	// Update is called once per frame
	void Update () {
		var port = rotate * Time.deltaTime;
		var starboard = -1 * rotate * Time.deltaTime;
		if(Input.GetKey(KeyCode.W))
			{
			transform.Translate (Vector3.forward * speed * Time.deltaTime);
			}
		if(Input.GetKey(KeyCode.A))
		{
			transform.Translate (Vector3.left * speed * Time.deltaTime);
			transform.Rotate (0, starboard, 0);
		}
		if(Input.GetKey(KeyCode.D))
		{
			transform.Translate (Vector3.right * speed * Time.deltaTime);
			transform.Rotate (0, port, 0);
		}
		if(Input.GetKey(KeyCode.S))
		{
			transform.Translate (Vector3.back * speed * Time.deltaTime);
		}
	}
}
